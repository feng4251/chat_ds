#!/bin/bash
# xClinicalTrial Orchestrator — 一键环境部署
# Author: Yinan Chen (陈翼男)
set -e

echo ""
echo "  ╔══════════════════════════════════════════════════════════════╗"
echo "  ║  xClinicalTrial Orchestrator v2.3 — 一键环境部署             ║"
echo "  ╚══════════════════════════════════════════════════════════════╝"
echo ""

# ── 1. Python 虚拟环境 ──
echo "── [1/3] 配置 Python 环境..."
python3 -m venv .venv
source .venv/bin/activate
pip install --upgrade pip -q
pip install -r requirements.txt -q
echo "   ✅ Python 依赖安装完成 (numpy, PyYAML, scipy, statsmodels)"

# ── 2. 安装技能到 Claude Code ──
echo "── [2/3] 安装外部数据库技能到 Claude Code..."
SKILLS_DIR="$HOME/.claude/skills"
mkdir -p "$SKILLS_DIR"
cp -r skills-bundle/* "$SKILLS_DIR/"
echo "   ✅ 18 个技能已安装到 $SKILLS_DIR/"

# ── 3. 注册项目技能 ──
echo "── [3/3] 注册项目主技能..."
echo "   项目路径: $(pwd)/trial-artifs-sim"
echo ""
echo "   ╔══════════════════════════════════════════════════════════════╗"
echo "   ║  ✅ 安装完成！在 Claude Code 中使用以下命令：                ║"
echo "   ║                                                            ║"
echo "   ║  cd $(pwd)/trial-artifs-sim                                 ║"
echo "   ║  /skill SKILL.md                                           ║"
echo "   ║                                                            ║"
echo "   ║  或者直接用自然语言：                                        ║"
echo "   ║  "请为我完成一个完整的临床试验设计"                            ║"
echo "   ╚══════════════════════════════════════════════════════════════╝"
echo ""
echo "  ── 管道脚本（可不依赖 Claude Code 直接运行）──"
echo "  source .venv/bin/activate"
echo "  cd trial-artifs-sim"
echo "  python scripts/generate_test_data.py --subjects 500 --output sdtm_json/"
echo "  python scripts/sdtm_validator.py --input sdtm_json/"
echo ""
