# xClinicalTrial Orchestrator v2.3 — Portable Package

**Author: Yinan Chen (陈翼男)**

## 概述

xClinicalTrial Orchestrator 是一个基于 Claude Code 的临床试验设计智能编排系统。通过 9 个专业化 Worker Agent (A→I) 并行协作，集成 18 个外部生物医学数据库，可针对任何治疗领域、任何试验阶段、任何设计类型自动生成完整的 I/II/III 期综合临床开发计划。

**v2.3 新增**: BOIN 剂量递增设计作为默认推荐、5 级生物标志物分级框架、Phase I→II PK 桥接、信号通路 ASCII 图、完整毒理学摘要表。

## 快速开始

### 1. 一键安装
```bash
chmod +x setup.sh
./setup.sh
```

### 2. 在 Claude Code 中启动
```bash
cd trial-artifs-sim
claude
```
然后输入: "请为我完成一个完整的临床试验设计"

### 3. 管道脚本独立运行（不需要 Claude Code）
```bash
source .venv/bin/activate
cd trial-artifs-sim

python scripts/generate_test_data.py --subjects 500 --output sdtm_json/
python scripts/sdtm_validator.py --input sdtm_json/ --output validation_report.json
python scripts/sdtm_to_csv.py --input sdtm_json/ --output sdtm_csv/
python scripts/sdtm_to_adam.py --input sdtm_json/ --output adam_json/
python scripts/submission_readiness.py --sdtm-dir sdtm_json/ --adam-dir adam_json/
python scripts/gal3_ad_statistical_simulation.py
```

## 系统要求

| 依赖 | 说明 |
|------|------|
| Python 3.10+ | 管道脚本运行环境 |
| Claude Code CLI | Worker 编排和 LLM 推理 |
| ~500 MB 磁盘 | 包含 18 个技能包 |

## Worker 团队 (9 个)

| ID | Worker | 职责 |
|----|--------|------|
| A | Safety & Efficacy Extractor | 安全性/疗效数据自动提取 |
| B | PICO & Standards Auditor | PICO + ICH/FDA/EMA 法规审计 + MC 统计模拟 |
| C | Termination Analyst | 历史试验终止分析 |
| D | I/E Criteria Designer | 入排标准设计与招募漏斗分析 |
| E | Biomarker Matcher | 生物标志物引导的患者-试验匹配 |
| F | AE Adjudicator | AE 判定与安全性预期特征 |
| G | Target Biology Analyzer | 靶点生物学深度分析 (11 DBs) |
| H | Competitive Landscape | 竞争格局与差异化策略 (7 DBs) |
| I | Literature Synthesis | 文献循证综合与引用图谱 (5 DBs) |

## 触发方式

| 一句话 | 触发的 Worker |
|--------|-------------|
| "请为我完成一个完整的临床试验设计" | 全部 9 Worker (comprehensive_design) |
| "帮我做一个全面的靶点分析" | Worker G |
| "分析竞争格局" | Worker H |
| "做一次系统的文献综述" | Worker I |
| "审核这个方案的法规合规性" | Worker B |
| "起草入排标准" | Worker D |

## 版本

| 版本 | 日期 | 变更 |
|------|------|------|
| 2.3 | 2026-07-01 | BOIN 首选推荐 + 毒理学摘要 + 生物标志物分级 + PK 桥接 + 叙述质量指令 |
| 2.2 | 2026-06-30 | Worker G/H/I + 14 数据库集成 + 全中文化 |
| 2.1 | 2026-06-29 | 6 Worker v2.1 |
| 2.0 | 2026-06-18 | 初始 CDISC 管道版本 |
